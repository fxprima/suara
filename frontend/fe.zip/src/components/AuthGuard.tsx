'use client';

import { useRouter } from 'next/navigation';
import { ReactNode, useEffect, useState } from 'react';
import LoadingScreen from './loader/LoadingScreen';
import useAuth from '@/hooks/useAuth';

type Props = {
    children: ReactNode;
    redirectTo?: string;
    requireAuth?: boolean;
};


export function AuthGuard({ children, redirectTo = '/', requireAuth = true }: Props) {
    const { isAuthenticated, loading } = useAuth();
    const router = useRouter();

    useEffect(() => {
        if (loading) return;
        if (requireAuth && !isAuthenticated) router.replace(redirectTo);
        if (!requireAuth && isAuthenticated) router.replace('/dashboard');
    }, [loading, isAuthenticated, requireAuth, redirectTo, router]);

    if (loading) return <LoadingScreen />;
    return <>{children}</>;
}
