"use client";
export default function LoadingScreen() {
  return (
    <div className="flex items-center justify-center h-screen bg-base-200">
      <div className="flex flex-col items-center space-y-4 animate-fade-in">
        <svg width="120" height="120" viewBox="0 0 550 547" fill="none" xmlns="http://www.w3.org/2000/svg" className="animate-bounce">
          <path
            d="M266.366 156.374C209.975 271.906 348.41 370.566 308.705 351.186C268.999 331.806 129.582 233.712 151.781 123.256C161.252 76.1355 233.289 11.7045 272.994 31.0847C312.7 50.4649 285.747 116.668 266.366 156.374Z"
            fill="#FFD000"
          />
          <path d="M5.16607 360.144C3.87922 404.308 34.0915 449.54 82.8021 442.44C289.266 412.345 306.297 583.192 307.584 539.028C308.871 494.864 259.1 348.94 93.4717 316.602C52.3836 308.58 6.45292 315.98 5.16607 360.144Z" fill="#FFD000" />
          <path
            d="M504.643 223.752C515.941 266.466 484.326 318.444 447.759 321.549C239.861 339.2 262.133 509.443 250.836 466.729C239.538 424.016 254.816 270.596 408.748 201.435C449.805 182.989 493.345 181.038 504.643 223.752Z"
            fill="#FFD000"
          />
        </svg>

        <span className="loading loading-spinner loading-lg text-primary animate-spin"></span>
        <h2 className="text-lg font-semibold text-base-content animate-pulse">Loading your experience...</h2>
      </div>
    </div>
  );
}
