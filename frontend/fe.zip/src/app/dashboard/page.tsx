import MainFeed from '@/components/feed/MainFeed';

export default function Dashboard() {
    return <MainFeed />;
}
