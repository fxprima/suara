export default function Dashboard() {
    return <div className="profile">Profile</div>;
}
