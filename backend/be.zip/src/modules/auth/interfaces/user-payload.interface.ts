export interface UserPayload {
    id: string;
    username: string;
}